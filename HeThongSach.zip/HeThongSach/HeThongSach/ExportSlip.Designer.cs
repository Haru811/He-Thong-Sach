﻿namespace HeThongSach
{
    partial class ExportSlip
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label17 = new Label();
            label16 = new Label();
            label15 = new Label();
            textBox12 = new TextBox();
            textBox11 = new TextBox();
            textBox10 = new TextBox();
            textBox9 = new TextBox();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            textBox8 = new TextBox();
            textBox7 = new TextBox();
            textBox6 = new TextBox();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textBox1 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaption;
            panel1.Controls.Add(label17);
            panel1.Controls.Add(label16);
            panel1.Controls.Add(label15);
            panel1.Controls.Add(textBox12);
            panel1.Controls.Add(textBox11);
            panel1.Controls.Add(textBox10);
            panel1.Controls.Add(textBox9);
            panel1.Controls.Add(label14);
            panel1.Controls.Add(label13);
            panel1.Controls.Add(label12);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(textBox8);
            panel1.Controls.Add(textBox7);
            panel1.Controls.Add(textBox6);
            panel1.Controls.Add(textBox5);
            panel1.Controls.Add(textBox4);
            panel1.Controls.Add(textBox3);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(textBox1);
            panel1.Location = new Point(47, 37);
            panel1.Name = "panel1";
            panel1.Size = new Size(834, 605);
            panel1.TabIndex = 3;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(622, 398);
            label17.Name = "label17";
            label17.Size = new Size(109, 15);
            label17.TabIndex = 30;
            label17.Text = "Director's signature";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(342, 398);
            label16.Name = "label16";
            label16.Size = new Size(109, 15);
            label16.TabIndex = 29;
            label16.Text = "Delivery's signature";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(57, 398);
            label15.Name = "label15";
            label15.Size = new Size(128, 15);
            label15.TabIndex = 28;
            label15.Text = "Export Staff's signature";
            // 
            // textBox12
            // 
            textBox12.Location = new Point(622, 337);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(122, 23);
            textBox12.TabIndex = 27;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(434, 337);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(128, 23);
            textBox11.TabIndex = 26;
            // 
            // textBox10
            // 
            textBox10.Location = new Point(681, 253);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(129, 23);
            textBox10.TabIndex = 25;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(544, 253);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(109, 23);
            textBox9.TabIndex = 24;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(622, 319);
            label14.Name = "label14";
            label14.Size = new Size(40, 15);
            label14.TabIndex = 22;
            label14.Text = "Slip ID";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(434, 319);
            label13.Name = "label13";
            label13.Size = new Size(90, 15);
            label13.TabIndex = 21;
            label13.Text = "Slip Export Date";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(681, 235);
            label12.Name = "label12";
            label12.Size = new Size(32, 15);
            label12.TabIndex = 20;
            label12.Text = "Total";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(544, 235);
            label11.Name = "label11";
            label11.Size = new Size(83, 15);
            label11.TabIndex = 19;
            label11.Text = "Price per Book";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label10.Location = new Point(32, 328);
            label10.Name = "label10";
            label10.Size = new Size(308, 32);
            label10.TabIndex = 18;
            label10.Text = "Published by V4T Company";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(425, 235);
            label9.Name = "label9";
            label9.Size = new Size(53, 15);
            label9.TabIndex = 17;
            label9.Text = "Quantity";
            // 
            // textBox8
            // 
            textBox8.Location = new Point(425, 253);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(100, 23);
            textBox8.TabIndex = 16;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(283, 253);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(100, 23);
            textBox7.TabIndex = 15;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(32, 253);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(218, 23);
            textBox6.TabIndex = 14;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(270, 171);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(135, 23);
            textBox5.TabIndex = 13;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(32, 171);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(190, 23);
            textBox4.TabIndex = 12;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(544, 108);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(277, 23);
            textBox3.TabIndex = 11;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(365, 108);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(148, 23);
            textBox2.TabIndex = 10;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(283, 235);
            label8.Name = "label8";
            label8.Size = new Size(48, 15);
            label8.TabIndex = 9;
            label8.Text = "Book ID";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(32, 235);
            label7.Name = "label7";
            label7.Size = new Size(69, 15);
            label7.TabIndex = 8;
            label7.Text = "Book Name";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(270, 153);
            label6.Name = "label6";
            label6.Size = new Size(89, 15);
            label6.TabIndex = 7;
            label6.Text = "Date of delivery";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(32, 153);
            label5.Name = "label5";
            label5.Size = new Size(84, 15);
            label5.TabIndex = 6;
            label5.Text = "Delivery Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(544, 90);
            label4.Name = "label4";
            label4.Size = new Size(49, 15);
            label4.TabIndex = 5;
            label4.Text = "Address";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(365, 90);
            label3.Name = "label3";
            label3.Size = new Size(86, 15);
            label3.TabIndex = 4;
            label3.Text = "Phone number";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(32, 90);
            label2.Name = "label2";
            label2.Size = new Size(69, 15);
            label2.TabIndex = 3;
            label2.Text = "Book Agent";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 36F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(299, 24);
            label1.Name = "label1";
            label1.Size = new Size(240, 55);
            label1.TabIndex = 2;
            label1.Text = "Export Slip";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(32, 108);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(304, 23);
            textBox1.TabIndex = 1;
            // 
            // button1
            // 
            button1.Location = new Point(703, 662);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 5;
            button1.Text = "Delete";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(793, 662);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 6;
            button2.Text = "Print";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // ExportSlip
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Info;
            ClientSize = new Size(928, 732);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(panel1);
            Name = "ExportSlip";
            Text = "ExportSlip";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label17;
        private Label label16;
        private Label label15;
        private TextBox textBox12;
        private TextBox textBox11;
        private TextBox textBox10;
        private TextBox textBox9;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label label9;
        private TextBox textBox8;
        private TextBox textBox7;
        private TextBox textBox6;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBox1;
        private Button button1;
        private Button button2;
    }
}