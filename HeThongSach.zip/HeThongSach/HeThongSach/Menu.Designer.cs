﻿namespace HeThongSach
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            pictureBox1 = new PictureBox();
            button7 = new Button();
            button8 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = SystemColors.Info;
            button1.Location = new Point(191, 132);
            button1.Name = "button1";
            button1.Size = new Size(152, 43);
            button1.TabIndex = 0;
            button1.Text = "Import Slip";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.Info;
            button2.Location = new Point(191, 197);
            button2.Name = "button2";
            button2.Size = new Size(152, 43);
            button2.TabIndex = 1;
            button2.Text = "Export Slip";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.Info;
            button3.Location = new Point(191, 270);
            button3.Name = "button3";
            button3.Size = new Size(152, 43);
            button3.TabIndex = 2;
            button3.Text = "Statistic";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = SystemColors.Info;
            button4.Location = new Point(191, 342);
            button4.Name = "button4";
            button4.Size = new Size(152, 43);
            button4.TabIndex = 3;
            button4.Text = "Book Info";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.BackColor = SystemColors.Info;
            button5.Location = new Point(462, 132);
            button5.Name = "button5";
            button5.Size = new Size(152, 43);
            button5.TabIndex = 4;
            button5.Text = "Publishing House Info";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.BackColor = SystemColors.Info;
            button6.Location = new Point(462, 197);
            button6.Name = "button6";
            button6.Size = new Size(152, 43);
            button6.TabIndex = 5;
            button6.Text = "Book Agent Info";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(836, 507);
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // button7
            // 
            button7.BackColor = SystemColors.Info;
            button7.Location = new Point(462, 270);
            button7.Name = "button7";
            button7.Size = new Size(152, 43);
            button7.TabIndex = 7;
            button7.Text = "Staff";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.BackColor = SystemColors.Info;
            button8.Location = new Point(462, 342);
            button8.Name = "button8";
            button8.Size = new Size(152, 43);
            button8.TabIndex = 8;
            button8.Text = "Statistic from Agent";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // Menu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(818, 480);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(pictureBox1);
            Name = "Menu";
            Text = "Menu";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private PictureBox pictureBox1;
        private Button button7;
        private Button button8;
    }
}